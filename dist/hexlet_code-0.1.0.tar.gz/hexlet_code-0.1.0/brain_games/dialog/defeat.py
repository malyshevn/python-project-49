

def defeat(answer, correct_answer, name):
    print(f"{answer} is wrong answer ;(. Correct answer was {correct_answer}\nLets try again, {name}")
